import React from 'react';
import Form from './components/Form/Form'; 

const App = () => {
  return (
    <div>
      <h1>Tech skills / Activity</h1>
      <Form />
    </div>
  );
};

export default App;
